#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif

    #if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)

    #ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    #endif

    return color;
}

vec4 read_chat_title(vec2 uv, float frame) {
    vec4 c=texture(Sampler0,uv);
    if(frame>0.5)c.a=clamp(c.a*(255.0/24.0),0.0,1.0);
    return c;
}
void main() {
    #ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
    #else
    ivec2 atlasSize = textureSize(Sampler0, 0);
    int ix = clamp(int(texCoord0.x * float(atlasSize.x)), 0, atlasSize.x - 1);
    vec4 marker0 = texelFetch(Sampler0, ivec2(ix, 0), 0);
    vec4 marker1 = texelFetch(Sampler0, ivec2(ix, 1), 0);
    bool animatedTitle = atlasSize.y == 256
        && all(lessThan(abs(marker0 - vec4(17.,231.,94.,1.)/255.), vec4(0.002)))
        && (all(lessThan(abs(marker1 - vec4(241.,43.,211.,1.)/255.), vec4(0.002)))
            || all(lessThan(abs(marker1 - vec4(241.,43.,212.,1.)/255.), vec4(0.002)))
            || all(lessThan(abs(marker1 - vec4(241.,43.,213.,1.)/255.), vec4(0.002)))
            || all(lessThan(abs(marker1 - vec4(241.,43.,214.,1.)/255.), vec4(0.002))));
    vec4 texColor;
    if (animatedTitle) {
        if (texCoord0.y >= 0.125) discard;
        bool richTitle = marker1.b > (213.5 / 255.0);
        bool calmTitle = marker1.b > (211.5 / 255.0) && !richTitle;
        float iconFraction = marker1.b > (212.5 / 255.0) ? 0.24 : 0.37;
        float iconY = texCoord0.y * 8.0;
        bool animatedIcon = calmTitle && texCoord0.x < iconFraction && iconY > 0.16 && iconY < 0.86;
        float frame = mod(floor(GameTime * (richTitle ? 7200.0 : (calmTitle && !animatedIcon ? 2000.0 : 7200.0))), 8.0);
        float localY = clamp(texCoord0.y * 8.0, 0.0, 1.0);
        texColor = read_chat_title(vec2(texCoord0.x, (frame * 32.0 + 2.5 + localY * 29.0) / 256.0),frame);
        bool smoothRichRim = richTitle && (localY < 0.16 || localY > 0.84 || texCoord0.x < 0.04 || texCoord0.x > 0.96);
        if ((calmTitle && !animatedIcon) || smoothRichRim) {
            float nextFrame = mod(frame + 1.0, 8.0);
            vec4 nextColor = read_chat_title(vec2(texCoord0.x, (nextFrame * 32.0 + 2.5 + localY * 29.0) / 256.0),nextFrame);
            texColor = mix(texColor, nextColor, fract(GameTime * (richTitle ? 7200.0 : 2000.0)));
        }
    } else {
        texColor = texture(Sampler0, texCoord0);
    }
    #endif

    vec4 color = texColor * vertexColor * ColorModulator;

    if (color.a < 0.1) {
        discard;
    }

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
